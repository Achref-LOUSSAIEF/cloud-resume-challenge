import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cloud-resume-challenge')

def lambda_handler(event, context):
    response = table.get_item(Key={'id': 'visitors'})

    if 'Item' in response:
        count = int(response['Item'].get('count', 0))
    else:
        count = 0

    count += 1

    table.put_item(Item={'id': 'visitors', 'count': count})

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type"
        },
        "body": json.dumps({"visitor_count": count})
    }
